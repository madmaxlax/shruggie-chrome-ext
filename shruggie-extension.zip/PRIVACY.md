# Privacy Policy — Shruggie Chrome Extension

Last updated: September 25, 2026

Shruggie is a Chrome extension that copies the text `¯\_(ツ)_/¯` to your clipboard when you click it. That's all it does.

**Data collection:** None. The extension does not collect, store, transmit, or share any personal or sensitive user data of any kind. It makes no network requests, runs no analytics, and sets no cookies.

**Permissions:** The extension requests the `clipboardWrite` permission. It is used solely to write the `¯\_(ツ)_/¯` text to your clipboard when you click the extension icon. Nothing else is read from or written to your clipboard.

**Changes:** If this policy changes, the updated version will be posted at this same address.

**Contact:** shruggie@madmaxlax.com
